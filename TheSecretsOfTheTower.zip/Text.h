#ifndef TEXT_H
#define TEXT_H

// use to store dialogue or descriptions




#endif