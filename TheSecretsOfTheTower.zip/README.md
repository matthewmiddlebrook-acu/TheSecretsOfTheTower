# Adventure Game

This is an adventure game created in C++ by Brighton Mica, Matthew Middlebrook, and Tommy Yates as a project for Object Oriented Programming at Abilene Christian University.