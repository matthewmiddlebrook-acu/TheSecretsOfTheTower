#include "Location.h"

#include <iostream>
using namespace std;